To run thrust test utilize the thrust test rig.

1. Connect potentiometer to throttle pins.
2. Connect ESCs to microcontroller
3. Have battery ready to connect to arm
4. Run script
5. Connect battery and wait for arming sequence to complete
6. Motors will begin to spin when throttle is live
7. Values will appear in terminal