from machine import Pin, PWM, ADC
import time

class DroneESC:
    def __init__(self, pin_num, min_pulse=1000, max_pulse=2000):
        self.pwm = PWM(Pin(pin_num))
        self.pwm.freq(50)  # Frequency of ESC (50Hz)
        self.min_pulse = min_pulse
        self.max_pulse = max_pulse
        # Calculate duty cycle range (0-65535 for Pico)
        self.min_duty = int((min_pulse / 20000) * 65535)
        self.max_duty = int((max_pulse / 20000) * 65535)

    def set_speed(self, throttle_percent):
        throttle_percent = max(0, min(100, throttle_percent))  # Clamp to 0-100%
        duty = int(self.min_duty + (throttle_percent / 100) * (self.max_duty - self.min_duty))
        self.pwm.duty_u16(duty)

    # Calibration of ESC
    def calibrate(self):
        print('Disconnect battery and press "Enter" when ready')
        time.sleep(10)

        # Set to maximum throttle
        self.set_speed(100)
        print('Connect battery now. Wait for beeps to conclude then press "Enter"')
        time.sleep(10)

        # Set to minimum throttle
        self.set_speed(0)
        print('Calibration complete')
        time.sleep(2)

    # Arming of the ESC
    def arm(self):
        self.set_speed(0)
        time.sleep(2)


# ---------------------- Setup ------------------------------
esc = DroneESC(0)       # ESC on GPIO 0
pot = ADC(Pin(28))      # Potentiometer wiper on GP28

 #esc.calibrate()        # Run when needed for calibration
esc.arm()
# -----------------------------------------------------------

# Potentiometer loop
while True:
    pot_value = pot.read_u16()           # 0 - 65535
    throttle = (pot_value / 65535) * 100  # Map to 0 - 100%
    print(f"POT: {pot_value}, Throttle: {throttle:.1f}%")

    esc.set_speed(throttle)
    time.sleep(0.05)  # Remove jitter